import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
public class Login{
    @Test
    public void login() 
    {


        System.setProperty("webdriver.chrome.driver","C:\\Users\\Divya.Bharathi\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://mobileworld.azurewebsites.net/");
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys("Vidya@gmail.com");
        driver.findElement(By.xpath("//input[@id='password']")).sendKeys("vidya123@");
        driver.findElement(By.xpath("//label[@for='remember-me']")).click();
        driver.findElement(By.xpath("//a[.='Log In']")).click();
    }
}
