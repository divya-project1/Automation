
	import java.time.Duration;
	import java.util.Iterator;
	import java.util.Set;
	import java.util.concurrent.TimeUnit;
	import org.openqa.selenium.Alert;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.support.ui.Select;
	import org.testng.annotations.Test;
	public class Order {
	@Test
	public void home() throws InterruptedException
	{
	    System.setProperty("webdriver.chrome.driver","C:\\Users\\Divya.Bharathi\\Downloads\\chromedriver_win32\\chromedriver.exe");
	    WebDriver driver=new ChromeDriver();
	    driver.manage().window().maximize();
	    driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
	    driver.get("https://mobileworld.azurewebsites.net/");
	    driver.findElement(By.xpath("(//a[@role='button'])[1]")).click(); //Latest click
	    driver.findElement(By.xpath("//a[@href='#samsung']")).click(); //Samsung click
	    driver.findElement(By.xpath("(//a[.='More Details'])[1]")).click(); //More details click
	    driver.findElement(By.id("myInput")).sendKeys("Sam");
	    //driver.findElement(By.xpath("//a[.='Apple']")).sendKeys("App");
	    //driver.findElement(By.xpath("(//a[.='More Details'])[1]")).click();
	    Thread.sleep(2000);
	    driver.findElement(By.id("navbarDropdown")).click(); //support click
	    Thread.sleep(2000);
	    driver.findElement(By.xpath("//a[.='Order']")).click(); //order click
	    Thread.sleep(2000);

	    Set<String>win=driver.getWindowHandles();
	    Iterator<String>it=win.iterator();
	    String parent = it.next();
	    String childId=it.next();
	    driver.switchTo().window(childId);

	    driver.findElement(By.id("inputFirstName")).sendKeys("Ashwini");
	    driver.findElement(By.xpath("(//input[@type='text'])[2]")).sendKeys("VR");
	    driver.findElement(By.id("inputEmail")).sendKeys("ravikumar@gmail.com");
	    driver.findElement(By.id("inputPassword")).sendKeys("ravikumar");
	    //driver.findElement(By.id("flexRadioDefault2")).click();
	    driver.findElement(By.xpath("//input[@placeholder='00000000000']")).sendKeys("98765432123");
	    driver.findElement(By.id(" address1")).sendKeys("Hosakote");
	    driver.findElement(By.id("address2")).sendKeys("Yalahanka");
	    driver.findElement(By.xpath("//input[@id='inputCity']")).sendKeys("Bangalore");

	    WebElement staticDropdown1=driver.findElement(By.id("inputState"));
	    Select dropdown1=new Select(staticDropdown1);
	    dropdown1.selectByVisibleText("Karnataka");
	    System.out.println(dropdown1.getFirstSelectedOption().getText());

	    driver.findElement(By.id("inputZip")).sendKeys("562114");
	    //driver.findElement(By.xpath("(//input[@type='checkbox'])[2]")).click();
	    Thread.sleep(5000);
	    driver.findElement(By.xpath("(//option[@id='Samsung'])[1]")).click();
	    driver.findElement(By.xpath("//input[@placeholder='no of mobiles']")).sendKeys("1");
	    WebElement staticDropdown2=driver.findElement(By.id("bought"));
	    Select dropdown2=new Select(staticDropdown2);
	    Thread.sleep(2000);
	    dropdown2.selectByVisibleText("No");
	    //driver.findElement(By.xpath("//input[@id='time']")).sendKeys("1");
	    Thread.sleep(2000);
	    //dropdown2.selectByVisibleText("No");
	    driver.findElement(By.xpath("(//input[@id='gridCheck1'])[1]")).click();
	    driver.findElement(By.xpath("(//input[@id='gridCheck1'])[2]")).click();

	    driver.findElement(By.xpath("//button[@type='button']")).click();
	    Thread.sleep(5000);
	    //Alert a2=driver.switchTo().alert();
	    //a2.accept();
	    driver.findElement(By.xpath("//a[.='Close']")).click();



	  }
	}

