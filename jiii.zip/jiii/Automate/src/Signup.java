import java.sql.Driver;
import org.openqa.selenium.WebElement;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
public class Signup {
    @Test
    public void rigister() throws InterruptedException
    {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\Divya.Bharathi\\Downloads\\chromedriver_win32\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.get("https://mobileworld.azurewebsites.net/");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        /*JavascriptExecutor js = ((JavascriptExecutor) driver);
          WebElement edit = driver.findElement(By.xpath("//button[@type='submit']"));
          js.executeScript("arguments[0].style.border='10px solid green'", edit);*/
        driver.findElement(By.xpath("//a[.='Sign up']")).click();
        driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("Tiger");
        driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("DB");
        driver.findElement(By.xpath("//input[@type='Email']")).sendKeys("vid@gmail.com");
        driver.findElement(By.xpath("//input[@type='Password']")).sendKeys("Imasf@123");
        driver.findElement(By.xpath("//input[@type='date']")).sendKeys("05/07/2020");
        driver.findElement(By.xpath("(//input[@type='radio'])[2]")).click();
        driver.findElement(By.xpath("//input[@placeholder='91XXXXXXXXXX']")).sendKeys("9876543212");
        driver.findElement(By.xpath("//textarea[@placeholder='Short Bio']")).sendKeys("HI HELLO IAM ASHWINI");
        driver.findElement(By.xpath("//button[.='Register']")).click();
        Thread.sleep(5000);
        driver.switchTo().alert().accept();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//button[@type='Submit']")).click();
        Thread.sleep(5000);
        driver.switchTo().alert().accept();

    }
}

