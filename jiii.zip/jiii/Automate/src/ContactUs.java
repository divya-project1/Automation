
	import java.util.Iterator;
	import java.util.Set;
	import java.util.concurrent.TimeUnit;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.annotations.Test;
	public class ContactUs {
	    @Test
	    public void contact() throws InterruptedException
	    {
	        System.setProperty("webdriver.chrome.driver","C:\\Users\\Divya.Bharathi\\Downloads\\chromedriver_win32\\chromedriver.exe");
	        WebDriver driver=new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
	        driver.get("https://mobileworld.azurewebsites.net/");
	        driver.findElement(By.xpath("(//a[@id='navbarDropdown'])[2]")).click();
	        Thread.sleep(2000);
	        driver.findElement(By.xpath("(//a[.='Contact Us'])[1]")).click();
	        Set<String>win=driver.getWindowHandles();
	        Iterator<String>it=win.iterator();
	        String parent = it.next();
	        String childId=it.next();
	        driver.switchTo().window(childId);
	        driver.manage().window().maximize();
	        driver.findElement(By.name("name")).sendKeys("King");
	        driver.findElement(By.name("email")).sendKeys("sush@gmail.com");
	        driver.findElement(By.name("phone")).sendKeys("98765434567");
	        driver.findElement(By.name("message")).sendKeys("Hi sush and siri");
	        driver.findElement(By.xpath("//input[@type='submit']")).click();
	    }
	}


